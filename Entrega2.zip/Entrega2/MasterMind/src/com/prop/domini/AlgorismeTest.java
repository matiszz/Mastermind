package com.prop.domini;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AlgorismeTest {

	@Test
	void crea_algorisme() {
		Algorisme a = new Algorisme();
		assertEquals(null,a);
	}
	
	@Test
	void aplica_logica() {	
	}
	
	@Test
	void busca_max() {	
	}
	
	@Test
	void elimina_incoherent() {	
	}
	
	@Test
	void genera_matriu() {	
	}
	
	@Test
	void busca_color() {	
	}
	
	@Test
	void genera_combinacions() {	
	}
	
	@Test
	void calcula_eliminacio_minima() {	
	}
	
	@Test
	void genera_random() {	
	}
}
